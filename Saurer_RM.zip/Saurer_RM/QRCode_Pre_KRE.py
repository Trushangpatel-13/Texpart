from kraken import binarization
from PIL import Image
from pyzbar.pyzbar import decode
from pyzbar.pyzbar import ZBarSymbol
import cv2
image_path = "./static/uploads/5.jpg"
# binarization using kraken
im = Image.open(image_path)
bi = cv2.resize(im, (500, 500))
bw_im = binarization.nlbin(bi)
# zbar
decode(bw_im, symbols=[ZBarSymbol.QRCODE])
while True:
    cv2.imshow("CV2",bw_im)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cv2.destroyAllWindows()