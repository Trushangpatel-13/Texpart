import os
from app import app
import urllib.request
from flask import Flask, flash, request, redirect, url_for, render_template, jsonify
from werkzeug.utils import secure_filename
from pyzbar.pyzbar import decode
import cv2
import numpy as np
from kraken import binarization

ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

def get_qr_data(input_frame):
    try:
        return decode(input_frame)
    except:
        return []


def draw_polygon(f_in, qro):
    if len(qro) == 0:
        return "Try Again"
    else:
        for obj in qro:
            text = obj.data.decode('utf-8')
            #print(text)
            #pts = np.array([obj.polygon], np.int32)
            #print("Before Reshape::", pts.shape)
            #pts = pts.reshape((4, 1, 2))
            #print("After Reshape::",pts.shape)
            #cv2.polylines(f_in, [pts], True, (255, 100, 5), 2)
            #cv2.putText(f_in, text, (50, 50), cv2.FONT_HERSHEY_PLAIN,1.5,(255,100,5),2)
        #return f_in
        return text
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def upload_form():
    return render_template('upload.html')


@app.route('/img_upload', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        #flash('No file part')
        return "No Image File"
    file = request.files['file']
    if file.filename == '':
        #flash('No image selected for uploading')
        return "No Image File"
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        #img = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        #frame_int = cv2.imread(img)How 
        #frame = cv2.resize(frame_int, (750, 750))
        #print(frame)
        #frame = cap
        #qr_obj = get_qr_data(frame)
        #print(qr_obj)
        #op_text = draw_polygon(frame, qr_obj)
        #print(op_text)
        #while True:
        #    cv2.imshow("CV2", frame)
        #    if cv2.waitKey(1) & 0xFF == ord('q'):
        #        break
        #cv2.destroyAllWindows()
        #flash(qr_obj)
        #flash(op_text)
        #return render_template('upload.html', filename=filename)
        return "Successfully Uploaded"
    else:
        flash('Allowed image types are -> png, jpg, jpeg, gif')
        return redirect(request.url)


@app.route('/display/<filename>')
def display_image(filename):
    # print('display_image filename: ' + filename)
    return redirect(url_for('static', filename='uploads/' + filename), code=301)


if __name__ == "__main__":
    app.run(host='192.168.163.106')