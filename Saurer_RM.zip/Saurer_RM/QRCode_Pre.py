import cv2
from pyzbar.pyzbar import decode
from pyzbar.pyzbar import ZBarSymbol

image_path = "./static/uploads/4.jpg"
# preprocessing using opencv
im = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
bi = cv2.resize(im, (500, 500))
blur = cv2.GaussianBlur(bi, (5, 5), 0)
ret, bw_im = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
while True:
    cv2.imshow("CV2",bw_im)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    decode(bw_im, symbols=[ZBarSymbol.QRCODE])
cv2.destroyAllWindows()
