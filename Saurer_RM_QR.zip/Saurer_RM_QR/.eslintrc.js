module.exports = {
  root: '',
  extends: '@react-native-community',
};
