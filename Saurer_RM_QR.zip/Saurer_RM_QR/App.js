import React from 'react';
import Scan from './src/scan';
import Wifi_config from './src/wifi_config';
import ImgUpload from './src/ImgUpload';

const App = () => {
  return (
    <ImgUpload />
  );
};
export default App;