import React from 'react';
import { View, Button } from 'react-native';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

const options_gallery = {
    title: 'select Image',
    type: 'library',
    options: {
        maxHeight: 750,
        maxWidth: 750,
        selectionLimit: 1,
        mediaType: 'photo',
        includeBase64: false,
        cropping: true
    }
}

const options_camera = {
    title: 'Take Photo',
    type: 'camera',
    options: {
        maxHeight: 750,
        maxWidth: 750,
        selectionLimit: 1,
        mediaType: 'photo',
        includeBase64: false,
        cropping: true
    }
}
const ImgUpload = () => {
    const openGallery= async ()=>{
        const images = await launchImageLibrary(options_gallery);
        console.log(images.assets[0])
        const formdata = new FormData()
        formdata.append('file',{
            uri : images.assets[0].uri,
            type: images.assets[0].type,
            name: images.assets[0].fileName
    })
    

        let res = await fetch(
            'http://192.168.163.106:5000/img_upload',
            {
                method:'post',
                body: formdata,
                headers:{
                    'Content-Type' : 'multipart/formdata;',
                },
            }
            
            );
            let responseJson = await res.json();
            console.log(responseJson,"ResponseJSON")
    }
    const openCamera= async ()=>{
        const images = await launchCamera(options_camera);
        console.log(images.assets[0])
        const formdata = new FormData()
        formdata.append('file',{
            uri : images.assets[0].uri,
            type: images.assets[0].type,
            name: images.assets[0].fileName
    })
    let res = await fetch(
        'http://192.168.163.106:5000/img_upload',
        {
            method:'post',
            body: formdata,
            headers:{
                'Content-Type' : 'multipart/formdata;',
            },
        }
        
        );
        let responseJson = await res.json();
        console.log(responseJson,"ResponseJSON")
    }
    return (
    <View 
    style = {{
        flex:1,
        alignItems:'center',
        justifyContent:'center'
    }}>
        <Button title="upload" onPress={openCamera}></Button>   
    </View>
  );
};
export default ImgUpload;